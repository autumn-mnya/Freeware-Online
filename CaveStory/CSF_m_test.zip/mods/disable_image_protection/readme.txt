This lets the game use edited .pbm (.bmp) files, by disabling an integrity check that would force the game to crash.
